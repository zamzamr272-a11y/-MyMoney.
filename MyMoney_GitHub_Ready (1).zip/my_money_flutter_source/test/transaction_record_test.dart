import 'package:flutter_test/flutter_test.dart';
import 'package:my_money/models/transaction_record.dart';

void main() {
  group('TransactionRecord', () {
    test('round-trips fields through the SQLite map shape', () {
      final original = TransactionRecord(
        id: 7,
        title: 'Lunch',
        amount: 25000,
        type: 'expense',
        category: 'Food',
        date: DateTime(2026, 10, 25, 12, 30),
        note: 'With friends',
        source: 'manual',
      );
      final decoded = TransactionRecord.fromMap(original.toMap());
      expect(decoded.id, 7);
      expect(decoded.title, 'Lunch');
      expect(decoded.amount, 25000);
      expect(decoded.type, 'expense');
      expect(decoded.category, 'Food');
      expect(decoded.date, original.date);
      expect(decoded.note, 'With friends');
      expect(decoded.source, 'manual');
    });

    test('copyWith updates a value without losing other fields', () {
      const record = TransactionRecord(
        id: 1,
        title: 'Payday',
        amount: 100000,
        type: 'income',
        category: 'Salary',
        date: DateTime(2026, 1, 1),
      );
      final updated = record.copyWith(amount: 125000);
      expect(updated.id, 1);
      expect(updated.amount, 125000);
      expect(updated.title, 'Payday');
      expect(updated.isIncome, isTrue);
    });
  });
}
