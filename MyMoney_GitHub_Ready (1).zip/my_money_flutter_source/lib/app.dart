import 'package:flutter/material.dart';
import 'package:local_auth/local_auth.dart';
import 'package:provider/provider.dart';

import 'l10n/app_strings.dart';
import 'providers/app_controller.dart';
import 'screens/add_transaction_screen.dart';
import 'screens/home_screen.dart';
import 'screens/reports_screen.dart';
import 'screens/scan_receipt_screen.dart';
import 'screens/settings_screen.dart';
import 'screens/transactions_screen.dart';
import 'utils/app_theme.dart';

class MyMoneyApp extends StatelessWidget {
  const MyMoneyApp({super.key});

  @override
  Widget build(BuildContext context) {
    final language = context.select<AppController, String>((c) => c.language);
    return MaterialApp(
      title: 'My Money',
      debugShowCheckedModeBanner: false,
      locale: Locale(language),
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: kCanvas,
        colorScheme: ColorScheme.fromSeed(seedColor: kPrimary, brightness: Brightness.light).copyWith(
          primary: kPrimary,
          secondary: kBlue,
          surface: Colors.white,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: kCanvas,
          foregroundColor: kPrimary,
          elevation: 0,
          scrolledUnderElevation: 0,
          centerTitle: false,
          titleTextStyle: TextStyle(color: kPrimary, fontSize: 20, fontWeight: FontWeight.w800),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: const Color(0xFFF5F8FC),
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: const BorderSide(color: Color(0xFFE4EBF3))),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: const BorderSide(color: kBlue, width: 1.5)),
          errorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: const BorderSide(color: Color(0xFFCF4A55))),
        ),
        cardTheme: CardThemeData(
          color: Colors.white,
          elevation: 0,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20), side: const BorderSide(color: Color(0xFFE9EFF5))),
        ),
        navigationBarTheme: NavigationBarThemeData(
          backgroundColor: Colors.white,
          indicatorColor: const Color(0xFFDDF7ED),
          labelTextStyle: WidgetStateProperty.resolveWith((states) => TextStyle(
            fontSize: 11,
            fontWeight: states.contains(WidgetState.selected) ? FontWeight.w800 : FontWeight.w500,
            color: states.contains(WidgetState.selected) ? kPrimary : Colors.blueGrey,
          )),
        ),
        snackBarTheme: SnackBarThemeData(
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        ),
      ),
      home: const AppLockGate(child: MainShell()),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _index = 0;

  Future<void> _addTransaction({bool scan = false}) async {
    if (scan) {
      await Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ScanReceiptScreen()));
    } else {
      await Navigator.of(context).push(MaterialPageRoute(builder: (_) => const AddTransactionScreen()));
    }
  }

  @override
  Widget build(BuildContext context) {
    final language = context.watch<AppController>().language;
    final titles = [
      AppStrings.get(language, 'home'),
      AppStrings.get(language, 'transactions'),
      AppStrings.get(language, 'reports'),
      AppStrings.get(language, 'settings'),
    ];
    return Scaffold(
      appBar: AppBar(
        title: Row(children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(color: kPrimary, borderRadius: BorderRadius.circular(11)),
            child: const Icon(Icons.account_balance_wallet_rounded, color: Colors.white, size: 21),
          ),
          const SizedBox(width: 10),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('My Money', style: TextStyle(fontSize: 18, color: kPrimary, fontWeight: FontWeight.w900)),
            Text(titles[_index], style: const TextStyle(fontSize: 11, color: Color(0xFF8192A3), fontWeight: FontWeight.w500)),
          ]),
        ]),
        actions: [
          IconButton(
            tooltip: AppStrings.get(language, 'scanDocument'),
            onPressed: () => _addTransaction(scan: true),
            icon: const Icon(Icons.document_scanner_outlined),
          ),
          const SizedBox(width: 4),
        ],
      ),
      body: IndexedStack(index: _index, children: [
        HomeScreen(onSeeAll: () => setState(() => _index = 1), onOpenSettings: () => setState(() => _index = 3)),
        const TransactionsScreen(),
        const ReportsScreen(),
        const SettingsScreen(),
      ]),
      bottomNavigationBar: SafeArea(
        top: false,
        child: Container(
          height: 70,
          padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 5),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
            boxShadow: [BoxShadow(color: const Color(0xFF0F2A22).withValues(alpha: 0.08), blurRadius: 24, offset: const Offset(0, -6))],
          ),
          child: Row(children: [
            _navItem(0, Icons.home_rounded, AppStrings.get(language, 'home')),
            _navItem(1, Icons.receipt_long_outlined, AppStrings.get(language, 'transactions')),
            Expanded(
              child: Center(
                child: Transform.translate(
                  offset: const Offset(0, -5),
                  child: Material(
                    color: kPrimary,
                    elevation: 4,
                    shape: const CircleBorder(),
                    child: InkWell(
                      customBorder: const CircleBorder(),
                      onTap: () => _addTransaction(),
                      child: const SizedBox(
                        width: 52,
                        height: 52,
                        child: Icon(Icons.add_rounded, color: Colors.white, size: 30),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            _navItem(2, Icons.bar_chart_rounded, AppStrings.get(language, 'reports')),
            _navItem(3, Icons.person_outline_rounded, AppStrings.get(language, 'account')),
          ]),
        ),
      ),
    );
  }

  Widget _navItem(int index, IconData icon, String label) {
    final selected = _index == index;
    return Expanded(
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: () => setState(() => _index = index),
        child: SizedBox(
          height: 58,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              AnimatedContainer(
                duration: const Duration(milliseconds: 220),
                curve: Curves.easeOutCubic,
                padding: EdgeInsets.symmetric(horizontal: selected ? 16 : 8, vertical: 3),
                decoration: BoxDecoration(color: selected ? const Color(0xFFDDF7ED) : Colors.transparent, borderRadius: BorderRadius.circular(14)),
                child: Icon(icon, size: 22, color: selected ? kPrimary : const Color(0xFF899A91)),
              ),
              const SizedBox(height: 3),
              Text(
                label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: 10,
                  height: 1.1,
                  fontWeight: selected ? FontWeight.w800 : FontWeight.w500,
                  color: selected ? kPrimary : const Color(0xFF899A91),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class AppLockGate extends StatefulWidget {
  const AppLockGate({super.key, required this.child});
  final Widget child;

  @override
  State<AppLockGate> createState() => _AppLockGateState();
}

class _AppLockGateState extends State<AppLockGate> with WidgetsBindingObserver {
  final LocalAuthentication _auth = LocalAuthentication();
  bool _unlocked = true;
  bool _authInProgress = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    final controller = context.read<AppController>();
    _unlocked = !controller.biometricLock;
    if (!_unlocked) WidgetsBinding.instance.addPostFrameCallback((_) => _authenticate());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && mounted && context.read<AppController>().biometricLock) {
      setState(() => _unlocked = false);
      _authenticate();
    }
  }

  Future<void> _authenticate() async {
    if (!mounted || _authInProgress) return;
    final controller = context.read<AppController>();
    if (!controller.biometricLock) {
      setState(() { _unlocked = true; _error = null; });
      return;
    }
    setState(() { _authInProgress = true; _error = null; });
    try {
      final supported = await _auth.isDeviceSupported();
      if (!mounted) return;
      if (!supported) {
        setState(() => _error = AppStrings.get(controller.language, 'authUnavailable'));
      } else {
        final success = await _auth.authenticate(
          localizedReason: AppStrings.get(controller.language, 'unlock'),
          options: const AuthenticationOptions(biometricOnly: false, stickyAuth: true),
        );
        if (mounted) setState(() {
          _unlocked = success;
          _error = success ? null : AppStrings.get(controller.language, 'authFailed');
        });
      }
    } catch (_) {
      if (mounted) setState(() => _error = AppStrings.get(controller.language, 'authUnavailable'));
    } finally {
      if (mounted) setState(() => _authInProgress = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final controller = context.watch<AppController>();
    if (!controller.biometricLock || _unlocked) return widget.child;
    return Scaffold(
      backgroundColor: kCanvas,
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(width: 76, height: 76, decoration: BoxDecoration(color: kPrimary, borderRadius: BorderRadius.circular(24)),
                child: const Icon(Icons.lock_rounded, color: Colors.white, size: 36)),
            const SizedBox(height: 20),
            const Text('My Money', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900, color: kPrimary)),
            const SizedBox(height: 8),
            Text(AppStrings.get(controller.language, 'unlock'), textAlign: TextAlign.center,
                style: TextStyle(color: Colors.blueGrey.shade600)),
            if (_error != null) ...[
              const SizedBox(height: 14),
              Text(_error!, textAlign: TextAlign.center, style: const TextStyle(color: Color(0xFFCF4A55))),
            ],
            const SizedBox(height: 22),
            FilledButton.icon(
              onPressed: _authInProgress ? null : _authenticate,
              icon: const Icon(Icons.fingerprint_rounded),
              label: Text(AppStrings.get(controller.language, 'retry')),
            ),
            TextButton(
              onPressed: () async {
                await controller.setBiometricLock(false);
                if (mounted) setState(() { _unlocked = true; _error = null; });
              },
              child: Text(controller.language == 'id' ? 'Matikan kunci aplikasi' : 'Turn off app lock'),
            ),
          ]),
        ),
      ),
    );
  }
}
