import 'package:flutter/material.dart';

const Color kPrimary = Color(0xFF087A55);
const Color kBlue = Color(0xFF0EB580);
const Color kCanvas = Color(0xFFF5F8FC);
