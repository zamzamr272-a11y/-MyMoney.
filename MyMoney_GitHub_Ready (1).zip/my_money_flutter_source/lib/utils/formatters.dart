import 'package:intl/intl.dart';

String formatCurrency(num amount, {String language = 'en'}) {
  final locale = language == 'id' ? 'id_ID' : 'en_US';
  return NumberFormat.currency(locale: locale, symbol: 'Rp', decimalDigits: 0)
      .format(amount);
}

String formatDate(DateTime date, {String language = 'en'}) {
  return DateFormat(language == 'id' ? 'dd MMM yyyy' : 'MMM dd, yyyy',
          language == 'id' ? 'id_ID' : 'en_US')
      .format(date);
}

String formatMonth(DateTime date, {String language = 'en'}) {
  return DateFormat(language == 'id' ? 'MMM' : 'MMM',
          language == 'id' ? 'id_ID' : 'en_US')
      .format(date);
}

String compactCurrency(num value, {String language = 'en'}) {
  final absValue = value.abs();
  if (absValue >= 1000000000) return 'Rp${(value / 1000000000).toStringAsFixed(1)}B';
  if (absValue >= 1000000) return 'Rp${(value / 1000000).toStringAsFixed(1)}M';
  if (absValue >= 1000) return 'Rp${(value / 1000).toStringAsFixed(0)}K';
  return formatCurrency(value, language: language);
}
