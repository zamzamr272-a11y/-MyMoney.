import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../utils/app_theme.dart';
import '../l10n/app_strings.dart';
import '../models/transaction_record.dart';
import '../providers/app_controller.dart';
import '../utils/formatters.dart';

class AddTransactionScreen extends StatefulWidget {
  const AddTransactionScreen({
    super.key,
    this.existing,
    this.initialAmount,
    this.initialTitle,
    this.initialCategory,
    this.initialSource = 'manual',
    this.initialType = 'expense',
  });

  final TransactionRecord? existing;
  final int? initialAmount;
  final String? initialTitle;
  final String? initialCategory;
  final String initialSource;
  final String initialType;

  @override
  State<AddTransactionScreen> createState() => _AddTransactionScreenState();
}

class _AddTransactionScreenState extends State<AddTransactionScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _title;
  late final TextEditingController _amount;
  late final TextEditingController _note;
  late String _type;
  late String _category;
  late DateTime _date;
  bool _saving = false;

  static const _expenseCategories = ['Food', 'Transport', 'Shopping', 'Bills', 'Health', 'Education', 'Housing', 'Cash', 'Other'];
  static const _incomeCategories = ['Salary', 'Business', 'Investment', 'Gift', 'Cash', 'Other'];

  List<String> get _categories => _type == 'income' ? _incomeCategories : _expenseCategories;

  @override
  void initState() {
    super.initState();
    final record = widget.existing;
    _title = TextEditingController(text: record?.title ?? widget.initialTitle ?? '');
    _amount = TextEditingController(text: (record?.amount ?? widget.initialAmount)?.toString() ?? '');
    _note = TextEditingController(text: record?.note ?? '');
    _type = record?.type ?? widget.initialType;
    _category = record?.category ?? widget.initialCategory ?? (_type == 'income' ? 'Salary' : 'Food');
    _date = record?.date ?? DateTime.now();
    if (!_categories.contains(_category)) _category = _categories.first;
  }

  @override
  void dispose() {
    _title.dispose();
    _amount.dispose();
    _note.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _date,
      firstDate: DateTime(2000),
      lastDate: DateTime.now().add(const Duration(days: 366)),
      builder: (context, child) => Theme(data: Theme.of(context), child: child!),
    );
    if (picked != null) setState(() => _date = DateTime(picked.year, picked.month, picked.day, _date.hour, _date.minute));
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    final controller = context.read<AppController>();
    setState(() => _saving = true);
    try {
      final record = TransactionRecord(
        id: widget.existing?.id,
        title: _title.text.trim(),
        amount: int.parse(_amount.text.replaceAll(RegExp(r'[^0-9]'), '')),
        type: _type,
        category: _category,
        date: _date,
        note: _note.text.trim(),
        source: widget.existing?.source ?? widget.initialSource,
      );
      if (widget.existing == null) {
        await controller.addTransaction(record);
      } else {
        await controller.updateTransaction(record);
      }
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(AppStrings.get(controller.language, widget.existing == null ? 'saved' : 'updated'))));
      Navigator.of(context).pop(true);
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${AppStrings.get(controller.language, 'error')}: $error')));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final controller = context.watch<AppController>();
    final language = controller.language;
    final editing = widget.existing != null;
    return Scaffold(
      appBar: AppBar(title: Text(AppStrings.get(language, editing ? 'editTransaction' : 'addTransaction'))),
      body: SafeArea(
        child: Form(
          key: _formKey,
          child: ListView(
            padding: const EdgeInsets.fromLTRB(18, 8, 18, 28),
            children: [
              Container(
                padding: const EdgeInsets.all(5),
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(17), border: Border.all(color: const Color(0xFFE4EBF3))),
                child: Row(children: [
                  _TypeButton(label: AppStrings.get(language, 'expenseType'), selected: _type == 'expense', color: const Color(0xFFCF4A55), onTap: () => _setType('expense')),
                  _TypeButton(label: AppStrings.get(language, 'incomeType'), selected: _type == 'income', color: const Color(0xFF16845B), onTap: () => _setType('income')),
                ]),
              ),
              const SizedBox(height: 22),
              Text(AppStrings.get(language, 'title'), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13)),
              const SizedBox(height: 8),
              TextFormField(
                controller: _title,
                textCapitalization: TextCapitalization.sentences,
                decoration: InputDecoration(hintText: language == 'id' ? 'Contoh: Makan siang' : 'e.g. Lunch'),
                validator: (value) => value == null || value.trim().isEmpty ? AppStrings.get(language, 'validTitle') : null,
              ),
              const SizedBox(height: 18),
              Text(AppStrings.get(language, 'amount'), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13)),
              const SizedBox(height: 8),
              TextFormField(
                controller: _amount,
                keyboardType: TextInputType.number,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                decoration: InputDecoration(prefixText: 'Rp ', hintText: '25000'),
                validator: (value) {
                  final amount = int.tryParse(value ?? '');
                  if (amount == null || amount <= 0) return AppStrings.get(language, 'validAmount');
                  return null;
                },
              ),
              const SizedBox(height: 18),
              Text(AppStrings.get(language, 'category'), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13)),
              const SizedBox(height: 8),
              DropdownButtonFormField<String>(
                value: _category,
                isExpanded: true,
                decoration: const InputDecoration(prefixIcon: Icon(Icons.category_outlined)),
                items: _categories.map((category) => DropdownMenuItem(value: category, child: Text(AppStrings.category(language, category)))).toList(),
                onChanged: (value) { if (value != null) setState(() => _category = value); },
              ),
              const SizedBox(height: 18),
              Text(AppStrings.get(language, 'date'), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13)),
              const SizedBox(height: 8),
              InkWell(
                onTap: _pickDate,
                borderRadius: BorderRadius.circular(15),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                  decoration: BoxDecoration(color: const Color(0xFFF5F8FC), borderRadius: BorderRadius.circular(15), border: Border.all(color: const Color(0xFFE4EBF3))),
                  child: Row(children: [const Icon(Icons.calendar_month_outlined, color: kPrimary), const SizedBox(width: 12), Expanded(child: Text(formatDate(_date, language: language))), const Icon(Icons.keyboard_arrow_down_rounded)],),
                ),
              ),
              const SizedBox(height: 18),
              Text(AppStrings.get(language, 'noteOptional'), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13)),
              const SizedBox(height: 8),
              TextFormField(controller: _note, maxLines: 3, textCapitalization: TextCapitalization.sentences,
                decoration: InputDecoration(hintText: language == 'id' ? 'Tambahkan detail jika diperlukan' : 'Add more detail if needed')),
              const SizedBox(height: 26),
              SizedBox(height: 54, child: FilledButton.icon(
                onPressed: _saving ? null : _save,
                icon: _saving ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Icon(Icons.check_rounded),
                label: Text(AppStrings.get(language, 'save'), style: const TextStyle(fontWeight: FontWeight.w800)),
              )),
              if (widget.initialSource != 'manual' && widget.existing == null) ...[
                const SizedBox(height: 12),
                Text(language == 'id' ? 'Nominal dari OCR hanya saran. Pastikan sesuai dokumen sebelum menyimpan.' : 'OCR amounts are suggestions. Verify the value against your document before saving.',
                    textAlign: TextAlign.center, style: TextStyle(color: Colors.blueGrey.shade500, fontSize: 11)),
              ],
            ],
          ),
        ),
      ),
    );
  }

  void _setType(String type) {
    setState(() {
      _type = type;
      if (!_categories.contains(_category)) _category = _categories.first;
    });
  }
}

class _TypeButton extends StatelessWidget {
  const _TypeButton({required this.label, required this.selected, required this.color, required this.onTap});
  final String label;
  final bool selected;
  final Color color;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => Expanded(
    child: InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 160),
        padding: const EdgeInsets.symmetric(vertical: 13),
        decoration: BoxDecoration(color: selected ? color.withOpacity(0.10) : Colors.transparent, borderRadius: BorderRadius.circular(12)),
        child: Center(child: Text(label, style: TextStyle(fontWeight: FontWeight.w800, color: selected ? color : Colors.blueGrey.shade500))),
      ),
    ),
  );
}
