import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../utils/app_theme.dart';
import '../l10n/app_strings.dart';
import '../providers/app_controller.dart';
import '../models/transaction_record.dart';
import 'add_transaction_screen.dart';
import '../utils/formatters.dart';
import '../widgets/chart_cards.dart';
import '../widgets/summary_stat_card.dart';
import '../widgets/transaction_tile.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key, this.onSeeAll, this.onOpenSettings});
  final VoidCallback? onSeeAll;
  final VoidCallback? onOpenSettings;

  @override
  Widget build(BuildContext context) {
    final controller = context.watch<AppController>();
    final language = controller.language;
    if (controller.isLoading) return const Center(child: CircularProgressIndicator());
    final now = DateTime.now();
    final summary = controller.lastSixMonths;
    return RefreshIndicator(
      onRefresh: controller.refreshTransactions,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(18, 8, 18, 28),
        children: [
          Text(AppStrings.get(language, 'hello'), style: const TextStyle(color: Color(0xFF0F2A22), fontSize: 20, fontWeight: FontWeight.w800, letterSpacing: -0.3)),
          const SizedBox(height: 16),
          _BalanceCard(balance: controller.currentBalance, language: language),
          const SizedBox(height: 14),
          Row(children: [
            SummaryStatCard(
              label: AppStrings.get(language, 'income'),
              value: formatCurrency(controller.getMonthIncome(), language: language),
              icon: Icons.south_west_rounded,
              tint: const Color(0xFFE6F6EF),
              valueColor: const Color(0xFF16845B),
            ),
            const SizedBox(width: 12),
            SummaryStatCard(
              label: AppStrings.get(language, 'expense'),
              value: formatCurrency(controller.getMonthExpense(), language: language),
              icon: Icons.north_east_rounded,
              tint: const Color(0xFFFFECEE),
              valueColor: const Color(0xFFCF4A55),
            ),
          ]),
          const SizedBox(height: 16),
          _SavingsGoalCard(
            name: controller.savingsGoalName,
            target: controller.savingsGoalTarget,
            balance: controller.currentBalance,
            language: language,
            onOpenSettings: onOpenSettings,
          ),
          const SizedBox(height: 24),
          BalanceTrendCard(summaries: summary, language: language),
          const SizedBox(height: 24),
          Row(children: [
            Expanded(child: Text(AppStrings.get(language, 'recentTransactions'),
                style: const TextStyle(color: kPrimary, fontWeight: FontWeight.w900, fontSize: 16))),
            TextButton(
              onPressed: onSeeAll,
              child: Text(AppStrings.get(language, 'seeAll')),
            ),
          ]),
          const SizedBox(height: 4),
          if (controller.recentTransactions.isEmpty)
            _EmptyTransactions(language: language)
          else
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: softCard(radius: 22),
              child: Column(children: [
                for (final item in controller.recentTransactions)
                  TransactionTile(transaction: item, language: language, onTap: () => _editTransaction(context, item)),
              ]),
            ),
          const SizedBox(height: 8),
          Text('${AppStrings.get(language, 'thisMonth')}: ${formatDate(DateTime(now.year, now.month, 1), language: language)}',
              textAlign: TextAlign.center, style: TextStyle(color: Colors.blueGrey.shade400, fontSize: 11)),
        ],
      ),
    );
  }

  void _editTransaction(BuildContext context, TransactionRecord item) {
    // Keep the dashboard read-only except opening a transaction editor from its context menu.
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => AddTransactionScreen(existing: item)));
  }
}

class _SavingsGoalCard extends StatelessWidget {
  const _SavingsGoalCard({required this.name, required this.target, required this.balance, required this.language, this.onOpenSettings});
  final String name;
  final int target;
  final int balance;
  final String language;
  final VoidCallback? onOpenSettings;

  @override
  Widget build(BuildContext context) {
    final isSet = target > 0;
    final trackedBalance = balance > 0 ? balance : 0;
    final progress = isSet ? (trackedBalance / target).clamp(0.0, 1.0).toDouble() : 0.0;
    return Container(
      padding: const EdgeInsets.all(17),
      decoration: softCard(radius: 22),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(width: 39, height: 39, decoration: BoxDecoration(color: const Color(0xFFE4F8EE), borderRadius: BorderRadius.circular(12)),
            child: const Icon(Icons.flag_outlined, color: kPrimary)),
          const SizedBox(width: 11),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(AppStrings.get(language, 'savingsGoal'), style: TextStyle(color: Colors.blueGrey.shade500, fontSize: 11.5)),
            const SizedBox(height: 3),
            Text(isSet ? name : AppStrings.get(language, 'goalNotSet'), maxLines: 2, overflow: TextOverflow.ellipsis,
              style: TextStyle(fontWeight: FontWeight.w800, fontSize: isSet ? 14 : 11.5, color: const Color(0xFF087A55))),
          ])),
          if (!isSet) TextButton(onPressed: onOpenSettings, child: Text(language == 'id' ? 'Atur' : 'Set')),
        ]),
        if (isSet) ...[
          const SizedBox(height: 15),
          Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Expanded(child: Text(formatCurrency(trackedBalance, language: language), style: const TextStyle(color: kPrimary, fontSize: 19, fontWeight: FontWeight.w900))),
            Text('${(progress * 100).round()}%', style: const TextStyle(color: kBlue, fontWeight: FontWeight.w900, fontSize: 13)),
          ]),
          const SizedBox(height: 9),
          ClipRRect(borderRadius: BorderRadius.circular(8), child: LinearProgressIndicator(value: progress, minHeight: 8,
              backgroundColor: const Color(0xFFE7EEF5), color: kBlue)),
          const SizedBox(height: 9),
          Text('${AppStrings.get(language, 'goalProgress')}: ${formatCurrency(target, language: language)}',
              style: TextStyle(color: Colors.blueGrey.shade500, fontSize: 10.5)),
          const SizedBox(height: 4),
          Text(language == 'id' ? 'Dihitung dari saldo saat ini; uang tidak dipisahkan otomatis.' : 'Based on current balance; money is not separated automatically.',
              style: TextStyle(color: Colors.blueGrey.shade400, fontSize: 10)),
        ],
      ]),
    );
  }
}

class _BalanceCard extends StatelessWidget {
  const _BalanceCard({required this.balance, required this.language});
  final int balance;
  final String language;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: const LinearGradient(colors: [Color(0xFF065F46), Color(0xFF087A55), Color(0xFF14C28E)], begin: Alignment.topLeft, end: Alignment.bottomRight),
        boxShadow: [BoxShadow(color: kPrimary.withValues(alpha: 0.32), blurRadius: 28, offset: const Offset(0, 14))],
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(padding: const EdgeInsets.all(8), decoration: BoxDecoration(color: Colors.white.withOpacity(0.13), borderRadius: BorderRadius.circular(12)),
              child: const Icon(Icons.account_balance_wallet_outlined, color: Colors.white, size: 18)),
          const SizedBox(width: 10),
          Text(AppStrings.get(language, 'totalBalance'), style: const TextStyle(color: Color(0xFFD7F6E8), fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 1.2)),
          const Spacer(),
          const Icon(Icons.more_horiz_rounded, color: Colors.white70),
        ]),
        const SizedBox(height: 20),
        FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft,
          child: Text(formatCurrency(balance, language: language), style: const TextStyle(color: Colors.white, fontSize: 34, fontWeight: FontWeight.w900, letterSpacing: -1))),
        const SizedBox(height: 18),
        Container(height: 1, color: Colors.white.withOpacity(0.17)),
        const SizedBox(height: 14),
        Row(children: [
          const Icon(Icons.shield_outlined, color: Color(0xFFB8EBD2), size: 15),
          const SizedBox(width: 7),
          Expanded(child: Text(language == 'id' ? 'Dihitung otomatis dari saldo awal + transaksi' : 'Automatically calculated from starting balance + transactions',
            style: const TextStyle(color: Color(0xFFD7F6E8), fontSize: 10.5))),
        ]),
      ]),
    );
  }
}

class _EmptyTransactions extends StatelessWidget {
  const _EmptyTransactions({required this.language});
  final String language;
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(22),
    decoration: softCard(radius: 22),
    child: Column(children: [
      Container(width: 56, height: 56, decoration: const BoxDecoration(color: Color(0xFFE4F8EE), shape: BoxShape.circle),
          child: const Icon(Icons.receipt_long_rounded, color: kPrimary, size: 26)),
      const SizedBox(height: 12),
      Text(AppStrings.get(language, 'noTransactions'), style: const TextStyle(fontWeight: FontWeight.w800)),
      const SizedBox(height: 5),
      Text(AppStrings.get(language, 'noTransactionsHint'), textAlign: TextAlign.center,
          style: TextStyle(color: Colors.blueGrey.shade500, fontSize: 12)),
    ]),
  );
}
