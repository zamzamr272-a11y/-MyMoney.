import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../l10n/app_strings.dart';
import '../models/transaction_record.dart';
import '../providers/app_controller.dart';
import 'add_transaction_screen.dart';
import '../utils/formatters.dart';
import '../widgets/transaction_tile.dart';

class TransactionsScreen extends StatefulWidget {
  const TransactionsScreen({super.key});

  @override
  State<TransactionsScreen> createState() => _TransactionsScreenState();
}

class _TransactionsScreenState extends State<TransactionsScreen> {
  final TextEditingController _search = TextEditingController();
  String _filter = 'all';

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final controller = context.watch<AppController>();
    final language = controller.language;
    final query = _search.text.trim().toLowerCase();
    final filtered = controller.transactions.where((transaction) {
      final typeMatches = _filter == 'all' || transaction.type == _filter;
      final textMatches = query.isEmpty ||
          transaction.title.toLowerCase().contains(query) ||
          transaction.category.toLowerCase().contains(query) ||
          transaction.note.toLowerCase().contains(query) ||
          transaction.amount.toString().contains(query);
      return typeMatches && textMatches;
    }).toList();
    final grouped = <String, List<TransactionRecord>>{};
    for (final transaction in filtered) {
      final key = '${transaction.date.year}-${transaction.date.month.toString().padLeft(2, '0')}';
      grouped.putIfAbsent(key, () => []).add(transaction);
    }

    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 8, 18, 24),
      children: [
        TextField(
          controller: _search,
          onChanged: (_) => setState(() {}),
          decoration: InputDecoration(
            hintText: AppStrings.get(language, 'searchTransactions'),
            prefixIcon: const Icon(Icons.search_rounded),
            suffixIcon: _search.text.isEmpty ? null : IconButton(
              onPressed: () { _search.clear(); setState(() {}); },
              icon: const Icon(Icons.close_rounded),
            ),
          ),
        ),
        const SizedBox(height: 14),
        Wrap(spacing: 8, children: [
          _FilterChip(label: AppStrings.get(language, 'all'), selected: _filter == 'all', onTap: () => setState(() => _filter = 'all')),
          _FilterChip(label: AppStrings.get(language, 'income'), selected: _filter == 'income', onTap: () => setState(() => _filter = 'income')),
          _FilterChip(label: AppStrings.get(language, 'expense'), selected: _filter == 'expense', onTap: () => setState(() => _filter = 'expense')),
        ]),
        const SizedBox(height: 18),
        if (filtered.isEmpty)
          _EmptyTransactions(language: language)
        else
          ...grouped.entries.map((group) {
            final pieces = group.key.split('-');
            final date = DateTime(int.parse(pieces[0]), int.parse(pieces[1]));
            final monthTotal = group.value.fold<int>(0, (sum, t) => sum + (t.isIncome ? t.amount : -t.amount));
            return Padding(
              padding: const EdgeInsets.only(bottom: 18),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Expanded(child: Text(formatMonth(date, language: language) + ' ${date.year}',
                      style: const TextStyle(color: Color(0xFF087A55), fontWeight: FontWeight.w900, fontSize: 14))),
                  Text('${monthTotal >= 0 ? '+' : '−'}${formatCurrency(monthTotal.abs(), language: language)}',
                      style: TextStyle(color: monthTotal >= 0 ? const Color(0xFF16845B) : const Color(0xFFCF4A55), fontWeight: FontWeight.w700, fontSize: 11)),
                ]),
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20), border: Border.all(color: const Color(0xFFE9EFF5))),
                  child: Column(children: group.value.map((t) => TransactionTile(
                    transaction: t,
                    language: language,
                    onTap: () => _edit(t),
                    onDelete: () => _delete(t),
                  )).toList()),
                ),
              ]),
            );
          }),
        if (filtered.isNotEmpty)
          Padding(padding: const EdgeInsets.only(top: 4), child: Text('${filtered.length} ${language == 'id' ? 'transaksi' : 'transactions'}',
            textAlign: TextAlign.center, style: TextStyle(color: Colors.blueGrey.shade400, fontSize: 11))),
      ],
    );
  }

  Future<void> _edit(TransactionRecord transaction) async {
    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => AddTransactionScreen(existing: transaction)));
  }

  Future<void> _delete(TransactionRecord transaction) async {
    final controller = context.read<AppController>();
    final language = controller.language;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(AppStrings.get(language, 'confirmDelete')),
        content: Text(AppStrings.get(language, 'deleteWarning')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: Text(AppStrings.get(language, 'cancel'))),
          FilledButton.tonal(onPressed: () => Navigator.pop(context, true), child: Text(AppStrings.get(language, 'delete'))),
        ],
      ),
    );
    if (confirmed == true && transaction.id != null) {
      await controller.deleteTransaction(transaction.id!);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(language == 'id' ? 'Transaksi dihapus' : 'Transaction deleted')));
    }
  }
}

class _FilterChip extends StatelessWidget {
  const _FilterChip({required this.label, required this.selected, required this.onTap});
  final String label;
  final bool selected;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => ChoiceChip(
    label: Text(label), selected: selected, onSelected: (_) => onTap(),
    showCheckmark: false,
    labelStyle: TextStyle(color: selected ? Colors.white : const Color(0xFF536779), fontWeight: FontWeight.w700, fontSize: 12),
    selectedColor: const Color(0xFF087A55), backgroundColor: Colors.white,
    side: BorderSide(color: selected ? const Color(0xFF087A55) : const Color(0xFFE1E8F0)),
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
  );
}

class _EmptyTransactions extends StatelessWidget {
  const _EmptyTransactions({required this.language});
  final String language;
  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(top: 10), padding: const EdgeInsets.all(25),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20), border: Border.all(color: const Color(0xFFE9EFF5))),
    child: Column(children: [
      const Icon(Icons.search_off_rounded, size: 40, color: Color(0xFF9AAABD)),
      const SizedBox(height: 10),
      Text(AppStrings.get(language, 'noTransactions'), style: const TextStyle(fontWeight: FontWeight.w800)),
      const SizedBox(height: 5),
      Text(AppStrings.get(language, 'noTransactionsHint'), textAlign: TextAlign.center, style: TextStyle(color: Colors.blueGrey.shade500, fontSize: 12)),
    ]),
  );
}
