import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:local_auth/local_auth.dart';
import 'package:provider/provider.dart';

import '../l10n/app_strings.dart';
import '../providers/app_controller.dart';
import '../services/export_service.dart';
import '../utils/formatters.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = context.watch<AppController>();
    final language = controller.language;
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 8, 18, 28),
      children: [
        _SettingsSection(title: language == 'id' ? 'Keuangan' : 'Finance', children: [
          _SettingsTile(
            icon: Icons.account_balance_wallet_outlined,
            title: AppStrings.get(language, 'setInitialBalance'),
            subtitle: formatCurrency(controller.initialBalance, language: language),
            onTap: () => _editInitialBalance(context),
          ),
          _SettingsTile(
            icon: Icons.flag_outlined,
            title: AppStrings.get(language, 'savingsGoal'),
            subtitle: controller.savingsGoalTarget > 0
                ? '${controller.savingsGoalName} · ${formatCurrency(controller.savingsGoalTarget, language: language)}'
                : AppStrings.get(language, 'goalNotSetShort'),
            onTap: () => _editSavingsGoal(context),
          ),
          _SettingsTile(
            icon: Icons.file_download_outlined,
            title: AppStrings.get(language, 'exportCsv'),
            subtitle: AppStrings.get(language, 'exportHint'),
            onTap: () => _export(context),
          ),
        ]),
        const SizedBox(height: 18),
        _SettingsSection(title: AppStrings.get(language, 'language'), children: [
          RadioListTile<String>(
            value: 'en', groupValue: language,
            onChanged: (value) { if (value != null) context.read<AppController>().setLanguage(value); },
            title: Text(AppStrings.get(language, 'english')),
            secondary: const Icon(Icons.translate_rounded, color: Color(0xFF087A55)),
            activeColor: const Color(0xFF087A55),
            contentPadding: const EdgeInsets.symmetric(horizontal: 15),
          ),
          RadioListTile<String>(
            value: 'id', groupValue: language,
            onChanged: (value) { if (value != null) context.read<AppController>().setLanguage(value); },
            title: Text(AppStrings.get(language, 'indonesian')),
            secondary: const Icon(Icons.language_rounded, color: Color(0xFF087A55)),
            activeColor: const Color(0xFF087A55),
            contentPadding: const EdgeInsets.symmetric(horizontal: 15),
          ),
        ]),
        const SizedBox(height: 18),
        _SettingsSection(title: AppStrings.get(language, 'security'), children: [
          SwitchListTile.adaptive(
            value: controller.biometricLock,
            onChanged: (value) => _toggleLock(context, value),
            secondary: const Icon(Icons.fingerprint_rounded, color: Color(0xFF087A55)),
            title: Text(AppStrings.get(language, 'biometricLock'), style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
            subtitle: Text(AppStrings.get(language, 'biometricHint'), style: TextStyle(color: Colors.blueGrey.shade500, fontSize: 11.5, height: 1.4)),
            activeTrackColor: const Color(0xFF087A55),
            contentPadding: const EdgeInsets.symmetric(horizontal: 15, vertical: 5),
          ),
        ]),
        const SizedBox(height: 18),
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(color: const Color(0xFFE4F8EE), borderRadius: BorderRadius.circular(20)),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Icon(Icons.shield_outlined, color: Color(0xFF087A55), size: 25),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(AppStrings.get(language, 'localPrivacy'), style: const TextStyle(color: Color(0xFF087A55), fontWeight: FontWeight.w900, fontSize: 14)),
              const SizedBox(height: 6),
              Text(AppStrings.get(language, 'localPrivacyHint'), style: const TextStyle(color: Color(0xFF376454), fontSize: 12, height: 1.45)),
            ])),
          ]),
        ),
        const SizedBox(height: 20),
        Center(child: Text('MY MONEY  •  v1.0.0', style: TextStyle(color: Colors.blueGrey.shade300, fontSize: 10, letterSpacing: 1.2, fontWeight: FontWeight.w700))),
      ],
    );
  }

  Future<void> _editInitialBalance(BuildContext context) async {
    final controller = context.read<AppController>();
    final language = controller.language;
    final text = TextEditingController(text: controller.initialBalance.round().toString());
    final result = await showDialog<int>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(AppStrings.get(language, 'setInitialBalance')),
        content: TextField(
          controller: text,
          autofocus: true,
          keyboardType: TextInputType.number,
          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
          decoration: const InputDecoration(prefixText: 'Rp ', hintText: '0'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: Text(AppStrings.get(language, 'cancel'))),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, int.tryParse(text.text)), child: Text(AppStrings.get(language, 'save'))),
        ],
      ),
    );
    text.dispose();
    if (result != null && result >= 0) await controller.setInitialBalance(result.toDouble());
  }

  Future<void> _editSavingsGoal(BuildContext context) async {
    final controller = context.read<AppController>();
    final language = controller.language;
    final name = TextEditingController(text: controller.savingsGoalTarget > 0 ? controller.savingsGoalName : '');
    final target = TextEditingController(text: controller.savingsGoalTarget > 0 ? controller.savingsGoalTarget.toString() : '');
    final result = await showDialog<Map<String, Object?>>(
      context: context,
      builder: (dialogContext) {
        String? error;
        return StatefulBuilder(builder: (dialogContext, setDialogState) => AlertDialog(
          title: Text(AppStrings.get(language, 'savingsGoal')),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(
              controller: name,
              textCapitalization: TextCapitalization.sentences,
              decoration: InputDecoration(labelText: AppStrings.get(language, 'goalName'), hintText: AppStrings.get(language, 'goalNameExample')),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: target,
              keyboardType: TextInputType.number,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              decoration: InputDecoration(labelText: AppStrings.get(language, 'goalTarget'), prefixText: 'Rp ', hintText: '1000000'),
            ),
            if (error != null) ...[
              const SizedBox(height: 8),
              Align(alignment: Alignment.centerLeft, child: Text(error!, style: const TextStyle(color: Color(0xFFCF4A55), fontSize: 12))),
            ],
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext), child: Text(AppStrings.get(language, 'cancel'))),
            FilledButton(onPressed: () {
              final parsed = int.tryParse(target.text);
              if (parsed == null || parsed <= 0) {
                setDialogState(() => error = AppStrings.get(language, 'validAmount'));
                return;
              }
              Navigator.pop(dialogContext, <String, Object?>{'name': name.text.trim(), 'target': parsed});
            }, child: Text(AppStrings.get(language, 'save'))),
          ],
        ));
      },
    );
    name.dispose();
    target.dispose();
    if (result != null) {
      await controller.setSavingsGoal(name: result['name'] as String, target: result['target'] as int);
      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(AppStrings.get(language, 'goalSaved'))));
    }
  }

  Future<void> _export(BuildContext context) async {
    final controller = context.read<AppController>();
    final messenger = ScaffoldMessenger.of(context);
    try {
      final file = await ExportService().exportCsv(controller.transactions, language: controller.language);
      await ExportService().shareFile(file);
      if (context.mounted) messenger.showSnackBar(SnackBar(content: Text('${AppStrings.get(controller.language, 'exportDone')}: ${file.path}')));
    } catch (error) {
      if (context.mounted) messenger.showSnackBar(SnackBar(content: Text('${AppStrings.get(controller.language, 'error')}: $error')));
    }
  }

  Future<void> _toggleLock(BuildContext context, bool value) async {
    final controller = context.read<AppController>();
    final language = controller.language;
    if (!value) {
      await controller.setBiometricLock(false);
      return;
    }
    try {
      final auth = LocalAuthentication();
      final supported = await auth.isDeviceSupported();
      if (!supported) {
        if (context.mounted) _showMessage(context, AppStrings.get(language, 'authUnavailable'));
        return;
      }
      final success = await auth.authenticate(
        localizedReason: AppStrings.get(language, 'unlock'),
        options: const AuthenticationOptions(biometricOnly: false, stickyAuth: true),
      );
      if (!context.mounted) return;
      if (success) {
        await controller.setBiometricLock(true);
        if (!context.mounted) return;
        _showMessage(context, language == 'id' ? 'Kunci aplikasi aktif saat aplikasi dibuka kembali.' : 'App lock is enabled for the next app opening.');
      } else {
        _showMessage(context, AppStrings.get(language, 'authFailed'));
      }
    } catch (_) {
      if (context.mounted) _showMessage(context, AppStrings.get(language, 'authUnavailable'));
    }
  }

  void _showMessage(BuildContext context, String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }
}

class _SettingsSection extends StatelessWidget {
  const _SettingsSection({required this.title, required this.children});
  final String title;
  final List<Widget> children;
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Padding(padding: const EdgeInsets.only(left: 3, bottom: 9), child: Text(title.toUpperCase(), style: TextStyle(color: Colors.blueGrey.shade500, fontSize: 10.5, fontWeight: FontWeight.w900, letterSpacing: 1.1))),
    Container(decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20), border: Border.all(color: const Color(0xFFE9EFF5))),
      child: Column(children: children)),
  ]);
}

class _SettingsTile extends StatelessWidget {
  const _SettingsTile({required this.icon, required this.title, required this.subtitle, required this.onTap});
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => ListTile(
    onTap: onTap, contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
    leading: Container(width: 42, height: 42, decoration: BoxDecoration(color: const Color(0xFFE4F8EE), borderRadius: BorderRadius.circular(13)),
      child: Icon(icon, color: const Color(0xFF087A55))),
    title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13)),
    subtitle: Padding(padding: const EdgeInsets.only(top: 4), child: Text(subtitle, style: TextStyle(color: Colors.blueGrey.shade500, fontSize: 11.5))),
    trailing: const Icon(Icons.chevron_right_rounded, color: Color(0xFF9AAABD)),
  );
}
