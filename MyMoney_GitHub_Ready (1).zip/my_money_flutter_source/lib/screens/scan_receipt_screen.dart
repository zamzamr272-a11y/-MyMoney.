import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../utils/app_theme.dart';
import '../l10n/app_strings.dart';
import '../providers/app_controller.dart';
import '../services/receipt_ocr_service.dart';
import '../utils/formatters.dart';
import 'add_transaction_screen.dart';

class ScanReceiptScreen extends StatefulWidget {
  const ScanReceiptScreen({super.key});

  @override
  State<ScanReceiptScreen> createState() => _ScanReceiptScreenState();
}

class _ScanReceiptScreenState extends State<ScanReceiptScreen> {
  final ImagePicker _picker = ImagePicker();
  final ReceiptOcrService _ocr = ReceiptOcrService();
  XFile? _image;
  String _recognizedText = '';
  List<int> _amounts = const [];
  int? _selectedAmount;
  bool _isReceipt = true;
  bool _working = false;
  String? _error;

  Future<void> _pick(ImageSource source) async {
    final language = context.read<AppController>().language;
    try {
      final image = await _picker.pickImage(source: source, imageQuality: 88, maxWidth: 2200);
      if (image == null) return;
      setState(() {
        _image = image;
        _recognizedText = '';
        _amounts = const [];
        _selectedAmount = null;
        _error = null;
      });
      await _readText();
    } catch (error) {
      if (mounted) setState(() => _error = '${AppStrings.get(language, 'error')}: $error');
    }
  }

  Future<void> _readText() async {
    if (_image == null) return;
    setState(() { _working = true; _error = null; });
    try {
      final result = await _ocr.recognizeFile(_image!.path, isReceipt: _isReceipt);
      if (!mounted) return;
      setState(() {
        _recognizedText = result.text;
        _amounts = result.amountCandidates;
        _selectedAmount = result.suggestedAmount;
      });
      if (result.text.isEmpty) setState(() => _error = AppStrings.get(context.read<AppController>().language, 'ocrFailed'));
    } catch (error) {
      if (mounted) setState(() => _error = '${AppStrings.get(context.read<AppController>().language, 'ocrFailed')}\n$error');
    } finally {
      if (mounted) setState(() => _working = false);
    }
  }

  Future<void> _continueToForm() async {
    final controller = context.read<AppController>();
    final source = _isReceipt ? 'receipt_ocr' : 'statement_ocr';
    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => AddTransactionScreen(
      initialAmount: _selectedAmount,
      initialTitle: _isReceipt ? (controller.language == 'id' ? 'Belanja dari struk' : 'Receipt purchase') : (controller.language == 'id' ? 'Transaksi mutasi' : 'Statement transaction'),
      initialCategory: _isReceipt ? 'Shopping' : 'Other',
      initialSource: source,
      initialType: 'expense',
    )));
  }

  @override
  Widget build(BuildContext context) {
    final language = context.watch<AppController>().language;
    return Scaffold(
      appBar: AppBar(title: Text(AppStrings.get(language, 'scanReceipt'))),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 8, 18, 28),
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(color: const Color(0xFFE4F8EE), borderRadius: BorderRadius.circular(18)),
            child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Icon(Icons.privacy_tip_outlined, color: kPrimary, size: 22),
              const SizedBox(width: 12),
              Expanded(child: Text(AppStrings.get(language, 'scanHint'), style: const TextStyle(color: kPrimary, fontSize: 12, height: 1.45))),
            ]),
          ),
          const SizedBox(height: 18),
          Text(AppStrings.get(language, 'documentType'), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 14)),
          const SizedBox(height: 9),
          SegmentedButton<bool>(
            segments: [
              ButtonSegment(value: true, label: Text(AppStrings.get(language, 'receipt')), icon: const Icon(Icons.receipt_long_outlined)),
              ButtonSegment(value: false, label: Text(AppStrings.get(language, 'statement')), icon: const Icon(Icons.account_balance_outlined)),
            ],
            selected: {_isReceipt},
            onSelectionChanged: (selection) {
              setState(() { _isReceipt = selection.first; _amounts = const []; _selectedAmount = null; _recognizedText = ''; });
              if (_image != null) _readText();
            },
            showSelectedIcon: false,
          ),
          const SizedBox(height: 18),
          Row(children: [
            Expanded(child: OutlinedButton.icon(onPressed: _working ? null : () => _pick(ImageSource.camera), icon: const Icon(Icons.photo_camera_outlined), label: Text(AppStrings.get(language, 'camera')))),
            const SizedBox(width: 10),
            Expanded(child: FilledButton.icon(onPressed: _working ? null : () => _pick(ImageSource.gallery), icon: const Icon(Icons.image_outlined), label: Text(AppStrings.get(language, 'gallery')))),
          ]),
          if (_image != null) ...[
            const SizedBox(height: 18),
            ClipRRect(borderRadius: BorderRadius.circular(18), child: Image.file(File(_image!.path), height: 190, width: double.infinity, fit: BoxFit.contain, errorBuilder: (_, __, ___) => const SizedBox(height: 100, child: Icon(Icons.image_not_supported_outlined)))),
            const SizedBox(height: 12),
            if (_working) const LinearProgressIndicator(minHeight: 3),
            if (!_working && _recognizedText.isNotEmpty)
              OutlinedButton.icon(onPressed: _readText, icon: const Icon(Icons.refresh_rounded), label: Text(AppStrings.get(language, 'recognize'))),
          ],
          if (_error != null) ...[
            const SizedBox(height: 12),
            Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: const Color(0xFFFFECEE), borderRadius: BorderRadius.circular(14)),
              child: Text(_error!, style: const TextStyle(color: Color(0xFFB42332), fontSize: 12))),
          ],
          if (_image != null && !_working) ...[
            const SizedBox(height: 18),
            Text(AppStrings.get(language, 'chooseAmount'), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 14)),
            const SizedBox(height: 5),
            Text(language == 'id' ? 'Pilih nominal yang benar. OCR bisa keliru membaca titik atau angka.' : 'Choose the correct value. OCR can misread punctuation or digits.',
                style: TextStyle(color: Colors.blueGrey.shade500, fontSize: 11.5)),
            const SizedBox(height: 12),
            if (_amounts.isEmpty)
              Text(AppStrings.get(language, 'noAmounts'), style: TextStyle(color: Colors.blueGrey.shade500, fontSize: 12))
            else
              Wrap(spacing: 8, runSpacing: 8, children: _amounts.take(16).map((amount) => ChoiceChip(
                selected: _selectedAmount == amount,
                label: Text(formatCurrency(amount, language: language)),
                onSelected: (_) => setState(() => _selectedAmount = amount),
                showCheckmark: false,
                selectedColor: const Color(0xFFD2F4E4),
                labelStyle: TextStyle(color: _selectedAmount == amount ? kPrimary : const Color(0xFF536779), fontWeight: FontWeight.w700),
              )).toList()),
            const SizedBox(height: 18),
            Text(AppStrings.get(language, 'recognizedText'), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 14)),
            const SizedBox(height: 8),
            Container(
              constraints: const BoxConstraints(maxHeight: 190),
              width: double.infinity,
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFFE4EBF3))),
              child: SingleChildScrollView(child: SelectableText(_recognizedText.isEmpty ? AppStrings.get(language, 'ocrFailed') : _recognizedText,
                style: TextStyle(fontSize: 12, height: 1.5, color: Colors.blueGrey.shade800))),
            ),
            const SizedBox(height: 22),
            SizedBox(height: 52, child: FilledButton.icon(onPressed: _continueToForm,
              icon: const Icon(Icons.arrow_forward_rounded), label: Text(AppStrings.get(language, 'useAmount')))),
          ],
        ],
      ),
    );
  }
}
