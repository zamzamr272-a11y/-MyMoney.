import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../l10n/app_strings.dart';
import '../providers/app_controller.dart';
import '../utils/formatters.dart';
import '../widgets/chart_cards.dart';

class ReportsScreen extends StatelessWidget {
  const ReportsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = context.watch<AppController>();
    final language = controller.language;
    final income = controller.getMonthIncome();
    final expense = controller.getMonthExpense();
    final net = income - expense;
    final date = DateTime.now();
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 8, 18, 28),
      children: [
        Text(AppStrings.get(language, 'monthlySummary'), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17, color: Color(0xFF087A55))),
        const SizedBox(height: 5),
        Text(formatDate(DateTime(date.year, date.month, 1), language: language), style: TextStyle(color: Colors.blueGrey.shade500, fontSize: 12)),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(19),
          decoration: softCard(radius: 22),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(AppStrings.get(language, 'netCashFlow'), style: TextStyle(color: Colors.blueGrey.shade500, fontSize: 12)),
            const SizedBox(height: 7),
            Text('${net >= 0 ? '+' : '−'}${formatCurrency(net.abs(), language: language)}',
              style: TextStyle(fontSize: 30, letterSpacing: -0.8, fontWeight: FontWeight.w900, color: net >= 0 ? const Color(0xFF16845B) : const Color(0xFFCF4A55))),
            const SizedBox(height: 14),
            Row(children: [
              Expanded(child: _ReportMini(label: AppStrings.get(language, 'income'), value: formatCurrency(income, language: language), color: const Color(0xFF16845B))),
              const SizedBox(width: 12),
              Expanded(child: _ReportMini(label: AppStrings.get(language, 'expense'), value: formatCurrency(expense, language: language), color: const Color(0xFFCF4A55))),
            ]),
          ]),
        ),
        const SizedBox(height: 22),
        CashFlowBarCard(summaries: controller.lastSixMonths, language: language),
        const SizedBox(height: 22),
        CategoryPieCard(values: controller.expensesByCategory(), language: language),
        const SizedBox(height: 18),
        Text(language == 'id'
            ? 'Laporan dihitung dari transaksi yang kamu masukkan. Pastikan saldo awal dan transaksi sudah benar.'
            : 'Reports are calculated from the transactions you enter. Keep your starting balance and records accurate.',
          style: TextStyle(color: Colors.blueGrey.shade500, fontSize: 11.5, height: 1.45)),
      ],
    );
  }
}

class _ReportMini extends StatelessWidget {
  const _ReportMini({required this.label, required this.value, required this.color});
  final String label;
  final String value;
  final Color color;
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(12),
    decoration: BoxDecoration(color: color.withOpacity(0.07), borderRadius: BorderRadius.circular(13)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(label, style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.w700)),
      const SizedBox(height: 5),
      FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft, child: Text(value, style: TextStyle(color: color, fontSize: 14, fontWeight: FontWeight.w900))),
    ]),
  );
}
