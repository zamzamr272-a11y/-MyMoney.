import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

import '../models/transaction_record.dart';

class AppDatabase {
  AppDatabase._();
  static final AppDatabase instance = AppDatabase._();
  Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    final root = await getDatabasesPath();
    final db = await openDatabase(
      p.join(root, 'my_money.db'),
      version: 1,
      onConfigure: (Database db) async {
        await db.execute('PRAGMA foreign_keys = ON');
      },
      onCreate: (Database db, int version) async {
        await db.execute('''
          CREATE TABLE transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            amount INTEGER NOT NULL CHECK(amount >= 0),
            type TEXT NOT NULL CHECK(type IN ('income', 'expense')),
            category TEXT NOT NULL,
            date TEXT NOT NULL,
            note TEXT NOT NULL DEFAULT '',
            source TEXT NOT NULL DEFAULT 'manual'
          )
        ''');
        await db.execute(
          'CREATE INDEX idx_transactions_date ON transactions(date DESC)',
        );
      },
    );
    _database = db;
    return db;
  }

  Future<List<TransactionRecord>> getTransactions() async {
    final db = await database;
    final rows = await db.query('transactions', orderBy: 'date DESC, id DESC');
    return rows.map(TransactionRecord.fromMap).toList(growable: true);
  }

  Future<int> insert(TransactionRecord record) async {
    final db = await database;
    return db.insert('transactions', record.toMap(),
        conflictAlgorithm: ConflictAlgorithm.abort);
  }

  Future<int> update(TransactionRecord record) async {
    if (record.id == null) throw ArgumentError('Cannot update without an id');
    final db = await database;
    return db.update(
      'transactions',
      record.toMap()..remove('id'),
      where: 'id = ?',
      whereArgs: [record.id],
      conflictAlgorithm: ConflictAlgorithm.abort,
    );
  }

  Future<int> delete(int id) async {
    final db = await database;
    return db.delete('transactions', where: 'id = ?', whereArgs: [id]);
  }
}
