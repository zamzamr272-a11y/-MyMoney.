import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../data/app_database.dart';
import '../models/transaction_record.dart';

class MonthSummary {
  const MonthSummary({
    required this.year,
    required this.month,
    required this.income,
    required this.expense,
    required this.endingBalance,
  });

  final int year;
  final int month;
  final int income;
  final int expense;
  final int endingBalance;
  int get net => income - expense;
}

class AppController extends ChangeNotifier {
  final AppDatabase _database = AppDatabase.instance;
  SharedPreferences? _preferences;
  List<TransactionRecord> _transactions = [];
  bool _isLoading = true;
  double _initialBalance = 0;
  String _language = 'en';
  bool _biometricLock = false;
  int _savingsGoalTarget = 0;
  String _savingsGoalName = 'Savings goal';

  List<TransactionRecord> get transactions => List.unmodifiable(_transactions);
  bool get isLoading => _isLoading;
  double get initialBalance => _initialBalance;
  String get language => _language;
  bool get biometricLock => _biometricLock;
  int get savingsGoalTarget => _savingsGoalTarget;
  String get savingsGoalName => _savingsGoalName;

  int get totalIncome => _transactions
      .where((item) => item.isIncome)
      .fold(0, (sum, item) => sum + item.amount);
  int get totalExpense => _transactions
      .where((item) => !item.isIncome)
      .fold(0, (sum, item) => sum + item.amount);
  int get currentBalance => _initialBalance.round() + totalIncome - totalExpense;

  Future<void> initialize() async {
    _isLoading = true;
    try {
      _preferences = await SharedPreferences.getInstance();
      _initialBalance = _preferences?.getDouble('initial_balance') ?? 0;
      _language = _preferences?.getString('language') ?? 'en';
      _biometricLock = _preferences?.getBool('biometric_lock') ?? false;
      _savingsGoalTarget = _preferences?.getInt('savings_goal_target') ?? 0;
      _savingsGoalName = _preferences?.getString('savings_goal_name') ?? 'Savings goal';
      _transactions = await _database.getTransactions();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  int getMonthIncome([DateTime? when]) {
    final date = when ?? DateTime.now();
    return _sumForMonth(date.year, date.month, true);
  }

  int getMonthExpense([DateTime? when]) {
    final date = when ?? DateTime.now();
    return _sumForMonth(date.year, date.month, false);
  }

  int _sumForMonth(int year, int month, bool income) {
    return _transactions
        .where((t) => t.date.year == year && t.date.month == month && t.isIncome == income)
        .fold(0, (sum, t) => sum + t.amount);
  }

  List<TransactionRecord> get recentTransactions => _transactions.take(5).toList();

  List<MonthSummary> get lastSixMonths {
    final now = DateTime.now();
    final months = List.generate(6, (index) {
      final date = DateTime(now.year, now.month - (5 - index), 1);
      return DateTime(date.year, date.month);
    });
    // Start the six-month trend from the balance at the beginning of the first month.
    final allSorted = [..._transactions]..sort((a, b) => a.date.compareTo(b.date));
    final summaries = <MonthSummary>[];
    final firstMonth = DateTime(months.first.year, months.first.month, 1);
    var runningBalance = _initialBalance.round();
    for (final item in allSorted.where((t) => t.date.isBefore(firstMonth))) {
      runningBalance += item.isIncome ? item.amount : -item.amount;
    }
    for (final month in months) {
      var monthIncome = 0;
      var monthExpense = 0;
      for (final item in allSorted) {
        if (item.date.year == month.year && item.date.month == month.month) {
          if (item.isIncome) {
            monthIncome += item.amount;
          } else {
            monthExpense += item.amount;
          }
        }
      }
      runningBalance += monthIncome - monthExpense;
      summaries.add(MonthSummary(
        year: month.year,
        month: month.month,
        income: monthIncome,
        expense: monthExpense,
        endingBalance: runningBalance,
      ));
    }
    return summaries;
  }

  Map<String, int> expensesByCategory({DateTime? period}) {
    final date = period ?? DateTime.now();
    final result = <String, int>{};
    for (final t in _transactions) {
      if (!t.isIncome && t.date.year == date.year && t.date.month == date.month) {
        result.update(t.category, (value) => value + t.amount, ifAbsent: () => t.amount);
      }
    }
    return result;
  }

  Future<void> addTransaction(TransactionRecord transaction) async {
    final id = await _database.insert(transaction);
    _transactions = [transaction.copyWith(id: id), ..._transactions];
    _transactions.sort((a, b) => b.date.compareTo(a.date));
    notifyListeners();
  }

  Future<void> updateTransaction(TransactionRecord transaction) async {
    await _database.update(transaction);
    _transactions = _transactions
        .map((item) => item.id == transaction.id ? transaction : item)
        .toList();
    _transactions.sort((a, b) => b.date.compareTo(a.date));
    notifyListeners();
  }

  Future<void> deleteTransaction(int id) async {
    await _database.delete(id);
    _transactions = _transactions.where((item) => item.id != id).toList();
    notifyListeners();
  }

  Future<void> setInitialBalance(double value) async {
    _initialBalance = value;
    await _preferences?.setDouble('initial_balance', value);
    notifyListeners();
  }

  Future<void> setLanguage(String value) async {
    if (value != 'en' && value != 'id') return;
    _language = value;
    await _preferences?.setString('language', value);
    notifyListeners();
  }

  Future<void> setBiometricLock(bool value) async {
    _biometricLock = value;
    await _preferences?.setBool('biometric_lock', value);
    notifyListeners();
  }

  Future<void> setSavingsGoal({required String name, required int target}) async {
    _savingsGoalName = name.trim().isEmpty ? (_language == 'id' ? 'Target tabungan' : 'Savings goal') : name.trim();
    _savingsGoalTarget = target < 0 ? 0 : target;
    await _preferences?.setString('savings_goal_name', _savingsGoalName);
    await _preferences?.setInt('savings_goal_target', _savingsGoalTarget);
    notifyListeners();
  }

  Future<void> refreshTransactions() async {
    _transactions = await _database.getTransactions();
    notifyListeners();
  }
}
