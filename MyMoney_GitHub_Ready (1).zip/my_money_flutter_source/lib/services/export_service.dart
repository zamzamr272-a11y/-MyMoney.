import 'dart:convert';
import 'dart:io';

import 'package:csv/csv.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import '../l10n/app_strings.dart';
import '../models/transaction_record.dart';

class ExportService {
  Future<File> exportCsv(List<TransactionRecord> transactions, {required String language}) async {
    final rows = <List<dynamic>>[
      ['id', 'date', 'type', 'title', 'category', 'amount_idr', 'note', 'source'],
      ...transactions.map((t) => <dynamic>[
            t.id ?? '',
            t.date.toIso8601String(),
            t.type,
            t.title,
            AppStrings.category(language, t.category),
            t.amount,
            t.note,
            t.source,
          ]),
    ];
    final content = const ListToCsvConverter().convert(rows);
    final directory = await getApplicationDocumentsDirectory();
    final file = File('${directory.path}/my_money_transactions.csv');
    // UTF-8 BOM makes the CSV more likely to open correctly in spreadsheet apps.
    await file.writeAsBytes(utf8.encode('\uFEFF$content'), flush: true);
    return file;
  }

  Future<void> shareFile(File file) async {
    await SharePlus.instance.share(
      ShareParams(
        files: [XFile(file.path, mimeType: 'text/csv')],
        subject: 'My Money transactions',
        text: 'My Money transaction export',
      ),
    );
  }
}
