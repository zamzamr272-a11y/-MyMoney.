import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';

class OcrResult {
  const OcrResult({required this.text, required this.amountCandidates, this.suggestedAmount});

  final String text;
  /// Candidate amounts in Indonesian rupiah, sorted with likely totals first.
  final List<int> amountCandidates;
  final int? suggestedAmount;
}

class ReceiptOcrService {
  ReceiptOcrService();

  Future<OcrResult> recognizeFile(String path, {required bool isReceipt}) async {
    final recognizer = TextRecognizer(script: TextRecognitionScript.latin);
    try {
      final image = InputImage.fromFilePath(path);
      final recognized = await recognizer.processImage(image);
      final text = recognized.text.trim();
      final candidates = _extractAmounts(text, isReceipt: isReceipt);
      return OcrResult(
        text: text,
        amountCandidates: candidates,
        suggestedAmount: candidates.isEmpty ? null : candidates.first,
      );
    } finally {
      await recognizer.close();
    }
  }

  List<int> _extractAmounts(String text, {required bool isReceipt}) {
    final lines = text.split(RegExp(r'[\r\n]+'));
    final totalLines = <int>[];
    if (isReceipt) {
      for (var i = 0; i < lines.length; i++) {
        if (RegExp(r'\b(total|grand total|jumlah|tagihan|bayar|amount due|total belanja|total pembayaran)\b',
                caseSensitive: false)
            .hasMatch(lines[i])) {
          totalLines.addAll(_amountsIn(lines[i]));
        }
      }
    }

    final all = <int>[];
    for (final line in lines) {
      all.addAll(_amountsIn(line));
    }
    final seen = <int>{};
    final unique = all.where((amount) => seen.add(amount)).toList();
    if (unique.isEmpty) return const [];

    // In a receipt, total-like lines have higher confidence than product lines.
    if (totalLines.isNotEmpty) {
      final uniqueTotals = <int>[];
      for (final value in totalLines.reversed) {
        if (!uniqueTotals.contains(value)) uniqueTotals.add(value);
      }
      uniqueTotals.sort((a, b) => b.compareTo(a));
      final rest = unique.where((value) => !uniqueTotals.contains(value)).toList()
        ..sort((a, b) => b.compareTo(a));
      return [...uniqueTotals, ...rest];
    }
    unique.sort((a, b) => b.compareTo(a));
    return unique;
  }

  List<int> _amountsIn(String line) {
    // Supports common IDR forms such as 12500, 12.500, 12,500 and Rp 12.500.
    final matches = RegExp(r'(?:Rp\.?\s*)?\b\d[\d.,]{1,}\b', caseSensitive: false)
        .allMatches(line);
    final values = <int>[];
    for (final match in matches) {
      final raw = match.group(0) ?? '';
      final digits = raw.replaceAll(RegExp(r'[^0-9]'), '');
      if (digits.length < 3 || digits.length > 12) continue;
      final amount = int.tryParse(digits);
      if (amount == null || amount <= 0 || amount > 999999999999) continue;
      if (!values.contains(amount)) values.add(amount);
    }
    return values;
  }
}
