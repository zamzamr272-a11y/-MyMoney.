class TransactionRecord {
  const TransactionRecord({
    this.id,
    required this.title,
    required this.amount,
    required this.type,
    required this.category,
    required this.date,
    this.note = '',
    this.source = 'manual',
  });

  final int? id;
  final String title;
  final int amount;
  /// Either `income` or `expense`.
  final String type;
  final String category;
  final DateTime date;
  final String note;
  /// `manual`, `receipt_ocr`, or `statement_ocr`.
  final String source;

  bool get isIncome => type == 'income';

  TransactionRecord copyWith({
    int? id,
    String? title,
    int? amount,
    String? type,
    String? category,
    DateTime? date,
    String? note,
    String? source,
    bool clearId = false,
  }) {
    return TransactionRecord(
      id: clearId ? null : (id ?? this.id),
      title: title ?? this.title,
      amount: amount ?? this.amount,
      type: type ?? this.type,
      category: category ?? this.category,
      date: date ?? this.date,
      note: note ?? this.note,
      source: source ?? this.source,
    );
  }

  Map<String, Object?> toMap() => {
        if (id != null) 'id': id,
        'title': title,
        'amount': amount,
        'type': type,
        'category': category,
        'date': date.toIso8601String(),
        'note': note,
        'source': source,
      };

  factory TransactionRecord.fromMap(Map<String, Object?> map) {
    return TransactionRecord(
      id: map['id'] as int?,
      title: map['title'] as String? ?? '',
      amount: (map['amount'] as num?)?.round() ?? 0,
      type: map['type'] as String? ?? 'expense',
      category: map['category'] as String? ?? 'Other',
      date: DateTime.tryParse(map['date'] as String? ?? '') ?? DateTime.now(),
      note: map['note'] as String? ?? '',
      source: map['source'] as String? ?? 'manual',
    );
  }
}
