import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';

import '../l10n/app_strings.dart';
import '../providers/app_controller.dart';
import '../utils/formatters.dart';

const Color moneyBlue = Color(0xFF0EB580);
const Color moneyNavy = Color(0xFF087A55);
const Color moneyGreen = Color(0xFF16845B);
const Color moneyRed = Color(0xFFE5575F);
const Color _axisText = Color(0xFF94A3B8);
const Color _gridLine = Color(0xFFEEF2F6);
const Color _tooltipBg = Color(0xFF0F2A22);

/// Kartu dasar: sudut besar + bayangan lembut, tanpa border kaku.
BoxDecoration softCard({double radius = 24}) => BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(radius),
      boxShadow: [
        BoxShadow(color: const Color(0xFF0F2A22).withValues(alpha: 0.05), blurRadius: 20, offset: const Offset(0, 8)),
      ],
    );

Widget _monthLabel(List<MonthSummary> s, double v, String lang, {bool highlightLast = true}) {
  final i = v.toInt();
  if (i < 0 || i >= s.length || v != i.toDouble()) return const SizedBox.shrink();
  final last = highlightLast && i == s.length - 1;
  return Padding(
    padding: const EdgeInsets.only(top: 10),
    child: Text(formatMonth(DateTime(s[i].year, s[i].month), language: lang),
        style: TextStyle(
            color: last ? moneyNavy : _axisText, fontSize: 11, fontWeight: last ? FontWeight.w800 : FontWeight.w500)),
  );
}

Widget _leftLabel(double v, TitleMeta meta, String lang) {
  if (v == meta.min || v == meta.max) return const SizedBox.shrink();
  return Text(compactCurrency(v, language: lang), style: const TextStyle(color: _axisText, fontSize: 10));
}

class BalanceTrendCard extends StatelessWidget {
  const BalanceTrendCard({super.key, required this.summaries, required this.language});
  final List<MonthSummary> summaries;
  final String language;

  @override
  Widget build(BuildContext context) {
    final balances = summaries.map((e) => e.endingBalance.toDouble()).toList();
    final maxV = balances.reduce((a, b) => a > b ? a : b);
    final minV = balances.reduce((a, b) => a < b ? a : b);
    final range = maxV - minV;
    final pad = range == 0 ? (maxV.abs() * 0.12 + 1000) : range * 0.25;
    final first = balances.first;
    final last = balances.last;
    final diff = last - first;
    final up = diff >= 0;
    final spots = [for (var i = 0; i < balances.length; i++) FlSpot(i.toDouble(), balances[i])];

    return Container(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 14),
      decoration: softCard(),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Expanded(
              child: Text(AppStrings.get(language, 'balanceTrend'),
                  style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15))),
          _Pill(
            icon: up ? Icons.trending_up_rounded : Icons.trending_down_rounded,
            text: compactCurrency(diff.abs(), language: language),
            color: up ? moneyGreen : moneyRed,
          ),
        ]),
        const SizedBox(height: 4),
        Text(language == 'id' ? '6 bulan terakhir · sentuh grafik untuk detail' : 'Last 6 months · tap the chart for details',
            style: const TextStyle(color: _axisText, fontSize: 11.5)),
        const SizedBox(height: 18),
        SizedBox(
          height: 200,
          child: LineChart(
            LineChartData(
              minY: minV - pad,
              maxY: maxV + pad,
              minX: 0,
              maxX: (summaries.length - 1).toDouble(),
              gridData: FlGridData(
                  drawVerticalLine: false,
                  getDrawingHorizontalLine: (_) => const FlLine(color: _gridLine, strokeWidth: 1, dashArray: [4, 4])),
              borderData: FlBorderData(show: false),
              titlesData: FlTitlesData(
                topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                leftTitles: AxisTitles(
                    sideTitles: SideTitles(
                        showTitles: true,
                        reservedSize: 46,
                        getTitlesWidget: (v, m) => _leftLabel(v, m, language))),
                bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                        showTitles: true,
                        interval: 1,
                        reservedSize: 30,
                        getTitlesWidget: (v, m) => _monthLabel(summaries, v, language))),
              ),
              lineTouchData: LineTouchData(
                handleBuiltInTouches: true,
                getTouchedSpotIndicator: (bar, idx) => [
                  TouchedSpotIndicatorData(
                    FlLine(color: moneyBlue.withValues(alpha: 0.35), strokeWidth: 1.5, dashArray: [4, 4]),
                    FlDotData(
                        getDotPainter: (s, p, b, i) =>
                            FlDotCirclePainter(radius: 6, color: Colors.white, strokeWidth: 3.5, strokeColor: moneyBlue)),
                  )
                ],
                touchTooltipData: LineTouchTooltipData(
                  getTooltipColor: (_) => _tooltipBg,
                  tooltipBorderRadius: BorderRadius.circular(12),
                  tooltipPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  getTooltipItems: (touched) => [
                    for (final t in touched)
                      LineTooltipItem(
                        '${formatMonth(DateTime(summaries[t.x.toInt()].year, summaries[t.x.toInt()].month), language: language)}\n',
                        const TextStyle(color: Color(0xFFA7D9C5), fontSize: 11),
                        children: [
                          TextSpan(
                              text: formatCurrency(t.y, language: language),
                              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 13)),
                        ],
                      )
                  ],
                ),
              ),
              lineBarsData: [
                LineChartBarData(
                  spots: spots,
                  isCurved: true,
                  curveSmoothness: 0.28,
                  preventCurveOverShooting: true,
                  barWidth: 3.5,
                  isStrokeCapRound: true,
                  gradient: const LinearGradient(colors: [moneyNavy, Color(0xFF2FD39A)]),
                  dotData: FlDotData(
                    getDotPainter: (s, p, b, i) => i == spots.length - 1
                        ? FlDotCirclePainter(radius: 5, color: Colors.white, strokeWidth: 3, strokeColor: moneyBlue)
                        : FlDotCirclePainter(radius: 0, color: Colors.transparent),
                  ),
                  belowBarData: BarAreaData(
                    show: true,
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [moneyBlue.withValues(alpha: 0.28), moneyBlue.withValues(alpha: 0.0)],
                    ),
                  ),
                ),
              ],
            ),
            duration: const Duration(milliseconds: 600),
            curve: Curves.easeOutCubic,
          ),
        ),
      ]),
    );
  }
}

class CashFlowBarCard extends StatelessWidget {
  const CashFlowBarCard({super.key, required this.summaries, required this.language});
  final List<MonthSummary> summaries;
  final String language;

  @override
  Widget build(BuildContext context) {
    final highest = summaries.fold<int>(0, (m, e) => [m, e.income, e.expense].reduce((a, b) => a > b ? a : b));
    final maxY = highest == 0 ? 10000.0 : highest.toDouble() * 1.2;

    BarChartRodData rod(num v, Color a, Color b) => BarChartRodData(
          toY: v.toDouble(),
          width: 11,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(6)),
          gradient: LinearGradient(begin: Alignment.bottomCenter, end: Alignment.topCenter, colors: [a, b]),
          backDrawRodData: BackgroundBarChartRodData(show: true, toY: maxY, color: const Color(0xFFF4F7FA)),
        );

    return Container(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 14),
      decoration: softCard(),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Expanded(
              child: Text(AppStrings.get(language, 'cashFlow'),
                  style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15))),
          _LegendDot(color: moneyBlue, label: AppStrings.get(language, 'income')),
          const SizedBox(width: 12),
          _LegendDot(color: moneyRed, label: AppStrings.get(language, 'expense')),
        ]),
        const SizedBox(height: 20),
        SizedBox(
          height: 210,
          child: BarChart(
            BarChartData(
              maxY: maxY,
              alignment: BarChartAlignment.spaceAround,
              gridData: FlGridData(
                  drawVerticalLine: false,
                  getDrawingHorizontalLine: (_) => const FlLine(color: _gridLine, strokeWidth: 1, dashArray: [4, 4])),
              borderData: FlBorderData(show: false),
              titlesData: FlTitlesData(
                topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                leftTitles: AxisTitles(
                    sideTitles: SideTitles(
                        showTitles: true, reservedSize: 46, getTitlesWidget: (v, m) => _leftLabel(v, m, language))),
                bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                        showTitles: true,
                        reservedSize: 30,
                        getTitlesWidget: (v, m) => _monthLabel(summaries, v, language))),
              ),
              barTouchData: BarTouchData(
                touchTooltipData: BarTouchTooltipData(
                  getTooltipColor: (_) => _tooltipBg,
                  tooltipBorderRadius: BorderRadius.circular(12),
                  getTooltipItem: (group, gi, r, ri) => BarTooltipItem(
                    formatCurrency(r.toY, language: language),
                    TextStyle(
                        color: ri == 0 ? const Color(0xFF5BE3B5) : const Color(0xFFFF9AA0),
                        fontWeight: FontWeight.w800,
                        fontSize: 12),
                  ),
                ),
              ),
              barGroups: [
                for (var i = 0; i < summaries.length; i++)
                  BarChartGroupData(x: i, barsSpace: 5, barRods: [
                    rod(summaries[i].income, moneyNavy, const Color(0xFF2FD39A)),
                    rod(summaries[i].expense, const Color(0xFFD83F4A), const Color(0xFFFF8A92)),
                  ]),
              ],
            ),
            duration: const Duration(milliseconds: 600),
            curve: Curves.easeOutCubic,
          ),
        ),
      ]),
    );
  }
}

class CategoryPieCard extends StatefulWidget {
  const CategoryPieCard({super.key, required this.values, required this.language});
  final Map<String, int> values;
  final String language;
  static const colors = [
    Color(0xFF0EB580), Color(0xFF3B82F6), Color(0xFFF59E0B), Color(0xFF8B5CF6),
    Color(0xFFEC4899), Color(0xFF06B6D4), Color(0xFFE5575F), Color(0xFF94A3B8),
  ];

  @override
  State<CategoryPieCard> createState() => _CategoryPieCardState();
}

class _CategoryPieCardState extends State<CategoryPieCard> {
  int _touched = -1;

  @override
  Widget build(BuildContext context) {
    final lang = widget.language;
    final entries = widget.values.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    final total = entries.fold<int>(0, (s, e) => s + e.value);
    final colors = CategoryPieCard.colors;
    final sel = _touched >= 0 && _touched < entries.length ? entries[_touched] : null;

    return Container(
      padding: const EdgeInsets.all(18),
      decoration: softCard(),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(AppStrings.get(lang, 'expenseByCategory'), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
        const SizedBox(height: 16),
        if (entries.isEmpty)
          Padding(
              padding: const EdgeInsets.symmetric(vertical: 16),
              child: Text(AppStrings.get(lang, 'noExpenseCategories'), style: const TextStyle(color: _axisText)))
        else ...[
          SizedBox(
            height: 190,
            child: Stack(alignment: Alignment.center, children: [
              PieChart(
                PieChartData(
                  sectionsSpace: 3,
                  centerSpaceRadius: 62,
                  startDegreeOffset: -90,
                  pieTouchData: PieTouchData(touchCallback: (event, resp) {
                    final i = resp?.touchedSection?.touchedSectionIndex ?? -1;
                    final end = !event.isInterestedForInteractions;
                    setState(() => _touched = end ? -1 : i);
                  }),
                  sections: [
                    for (var i = 0; i < entries.length; i++)
                      PieChartSectionData(
                        value: entries[i].value.toDouble(),
                        color: colors[i % colors.length],
                        radius: i == _touched ? 30 : 24,
                        showTitle: false,
                      )
                  ],
                ),
                duration: const Duration(milliseconds: 350),
              ),
              IgnorePointer(
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Text(sel == null ? (lang == 'id' ? 'Total' : 'Total') : AppStrings.category(lang, sel.key),
                      style: const TextStyle(color: _axisText, fontSize: 11.5)),
                  const SizedBox(height: 2),
                  Text(compactCurrency(sel?.value ?? total, language: lang),
                      style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 20, color: moneyNavy)),
                  if (sel != null)
                    Text('${(sel.value / total * 100).round()}%',
                        style: TextStyle(color: colors[_touched % colors.length], fontWeight: FontWeight.w800, fontSize: 12)),
                ]),
              ),
            ]),
          ),
          const SizedBox(height: 14),
          for (var i = 0; i < entries.length && i < 6; i++)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 6),
              child: Column(children: [
                Row(children: [
                  Container(
                      width: 10,
                      height: 10,
                      decoration: BoxDecoration(color: colors[i % colors.length], borderRadius: BorderRadius.circular(3))),
                  const SizedBox(width: 10),
                  Expanded(
                      child: Text(AppStrings.category(lang, entries[i].key),
                          style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600))),
                  Text(formatCurrency(entries[i].value, language: lang),
                      style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w800)),
                  SizedBox(
                      width: 42,
                      child: Text('${(entries[i].value / total * 100).round()}%',
                          textAlign: TextAlign.right, style: const TextStyle(fontSize: 12, color: _axisText))),
                ]),
                const SizedBox(height: 6),
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: LinearProgressIndicator(
                      value: entries[i].value / total,
                      minHeight: 5,
                      backgroundColor: const Color(0xFFF1F5F9),
                      color: colors[i % colors.length]),
                ),
              ]),
            ),
        ],
      ]),
    );
  }
}

class _Pill extends StatelessWidget {
  const _Pill({required this.icon, required this.text, required this.color});
  final IconData icon;
  final String text;
  final Color color;
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: BoxDecoration(color: color.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(20)),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, size: 15, color: color),
          const SizedBox(width: 4),
          Text(text, style: TextStyle(color: color, fontWeight: FontWeight.w800, fontSize: 12)),
        ]),
      );
}

class _LegendDot extends StatelessWidget {
  const _LegendDot({required this.color, required this.label});
  final Color color;
  final String label;
  @override
  Widget build(BuildContext context) => Row(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 8, height: 8, decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
        const SizedBox(width: 5),
        Text(label, style: const TextStyle(fontSize: 11, color: Color(0xFF64748B), fontWeight: FontWeight.w600)),
      ]);
}
