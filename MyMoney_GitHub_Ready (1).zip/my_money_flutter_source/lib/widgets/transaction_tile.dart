import 'package:flutter/material.dart';

import '../l10n/app_strings.dart';
import '../models/transaction_record.dart';
import '../utils/formatters.dart';

class TransactionTile extends StatelessWidget {
  const TransactionTile({
    super.key,
    required this.transaction,
    required this.language,
    this.onTap,
    this.onDelete,
  });

  final TransactionRecord transaction;
  final String language;
  final VoidCallback? onTap;
  final VoidCallback? onDelete;

  IconData _iconForCategory(String category) => switch (category) {
        'Food' => Icons.restaurant_rounded,
        'Transport' => Icons.directions_car_filled_rounded,
        'Shopping' => Icons.shopping_bag_rounded,
        'Bills' => Icons.receipt_long_rounded,
        'Health' => Icons.favorite_rounded,
        'Education' => Icons.school_rounded,
        'Salary' => Icons.work_rounded,
        'Business' => Icons.storefront_rounded,
        'Investment' => Icons.trending_up_rounded,
        'Gift' => Icons.card_giftcard_rounded,
        'Housing' => Icons.home_rounded,
        'Cash' => Icons.payments_rounded,
        _ => Icons.swap_horiz_rounded,
      };

  @override
  Widget build(BuildContext context) {
    final isIncome = transaction.isIncome;
    final color = isIncome ? const Color(0xFF16845B) : const Color(0xFFCF4A55);
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 10),
        child: Row(
          children: [
            Container(
              width: 46,
              height: 46,
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(15),
              ),
              child: Icon(_iconForCategory(transaction.category), color: color),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(transaction.title, maxLines: 1, overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
                  const SizedBox(height: 4),
                  Text('${AppStrings.category(language, transaction.category)} · ${formatDate(transaction.date, language: language)}',
                      maxLines: 1, overflow: TextOverflow.ellipsis,
                      style: TextStyle(color: Colors.blueGrey.shade500, fontSize: 11.5)),
                ],
              ),
            ),
            const SizedBox(width: 8),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text('${isIncome ? '+' : '−'}${formatCurrency(transaction.amount, language: language)}',
                    style: TextStyle(color: color, fontSize: 14, fontWeight: FontWeight.w800)),
                if (onDelete != null)
                  IconButton(
                    visualDensity: VisualDensity.compact,
                    constraints: const BoxConstraints(minWidth: 30, minHeight: 30),
                    padding: EdgeInsets.zero,
                    icon: Icon(Icons.delete_outline_rounded, size: 17, color: Colors.blueGrey.shade300),
                    onPressed: onDelete,
                    tooltip: AppStrings.get(language, 'delete'),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
