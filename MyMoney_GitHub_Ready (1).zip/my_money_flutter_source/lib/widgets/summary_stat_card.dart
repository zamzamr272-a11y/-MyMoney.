import 'package:flutter/material.dart';

class SummaryStatCard extends StatelessWidget {
  const SummaryStatCard({
    super.key,
    required this.label,
    required this.value,
    required this.icon,
    required this.tint,
    required this.valueColor,
  });

  final String label;
  final String value;
  final IconData icon;
  final Color tint;
  final Color valueColor;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(22),
          boxShadow: [BoxShadow(color: const Color(0xFF0F2A22).withValues(alpha: 0.05), blurRadius: 20, offset: const Offset(0, 8))],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              Container(
                padding: const EdgeInsets.all(9),
                decoration: BoxDecoration(color: valueColor.withValues(alpha: 0.12), shape: BoxShape.circle),
                child: Icon(icon, size: 18, color: valueColor),
              ),
              const Spacer(),
            ]),
            const SizedBox(height: 15),
            Text(label, style: TextStyle(fontSize: 12, color: Colors.blueGrey.shade600)),
            const SizedBox(height: 5),
            FittedBox(
              fit: BoxFit.scaleDown,
              alignment: Alignment.centerLeft,
              child: Text(value, style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18, letterSpacing: -0.3, color: valueColor)),
            ),
          ],
        ),
      ),
    );
  }
}
