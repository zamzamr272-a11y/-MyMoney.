# My Money Flutter source

Flutter source code for the My Money Android app. The repository-level README explains how GitHub Actions prepares Android, runs tests, builds the APK, and publishes a GitHub Release.

Run `flutter pub get`, `flutter analyze`, `flutter test`, and `flutter build apk --release` inside this folder only after a standard Android platform folder has been created. In this repository, GitHub Actions creates and configures that folder automatically.
