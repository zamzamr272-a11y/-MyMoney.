#!/usr/bin/env python3
"""Prepare a generated Flutter Android project for the My Money app.

This script is deliberately idempotent: running it more than once should not
add duplicate Gradle blocks, manifest permissions, or icon resources.
"""

from __future__ import annotations

import re
import shutil
import sys
from pathlib import Path

PACKAGE = "id.mymoney.my_money"
ACTIVITY_SOURCE = (
    f"package {PACKAGE}\n\n"
    "import io.flutter.embedding.android.FlutterFragmentActivity\n\n"
    "class MainActivity : FlutterFragmentActivity()\n"
)


def matching_brace(text: str, opening: int) -> int:
    """Return the matching closing brace, ignoring braces in comments/strings."""
    depth = 0
    i = opening
    state = "normal"
    quote = ""
    while i < len(text):
        ch = text[i]
        nxt = text[i + 1] if i + 1 < len(text) else ""

        if state == "line_comment":
            if ch == "\n":
                state = "normal"
            i += 1
            continue
        if state == "block_comment":
            if ch == "*" and nxt == "/":
                state = "normal"
                i += 2
            else:
                i += 1
            continue
        if state == "string":
            if ch == "\\":
                i += 2
                continue
            if ch == quote:
                # Triple-quoted strings are not expected in the generated file;
                # still support ordinary and triple-quoted Kotlin/Groovy strings.
                if text[i : i + 3] == quote * 3:
                    state = "normal"
                    i += 3
                    continue
                state = "normal"
            i += 1
            continue

        if ch == "/" and nxt == "/":
            state = "line_comment"
            i += 2
            continue
        if ch == "/" and nxt == "*":
            state = "block_comment"
            i += 2
            continue
        if ch in ("'", '"'):
            quote = ch
            if text[i : i + 3] == ch * 3:
                i += 3
                state = "string"
                # matching_brace's string parser checks quote*3 below as well.
                quote = ch
                continue
            state = "string"
            i += 1
            continue
        if ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                return i
        i += 1
    raise ValueError("Unmatched opening brace in Gradle file")


def find_block(text: str, name: str, start: int = 0, end: int | None = None):
    """Find a named Gradle block and return (line_indent, open_index, close_index)."""
    stop = len(text) if end is None else end
    pattern = re.compile(rf"(?m)^([ \t]*){re.escape(name)}\s*\{{")
    for match in pattern.finditer(text, start, stop):
        opening = text.find("{", match.start(), match.end())
        closing = matching_brace(text, opening)
        if closing < stop:
            return match.group(1), opening, closing
    return None


def ensure_release_options(gradle_text: str, is_kotlin: bool) -> str:
    android = find_block(gradle_text, "android")
    if android is None:
        raise ValueError("Could not find the android { } block in app Gradle file")

    build_types = find_block(gradle_text, "buildTypes", android[1], android[2])
    if build_types is None:
        android_indent = android[0]
        inner = android_indent + "    "
        release_indent = inner + "    "
        if is_kotlin:
            new_block = (
                f"\n{inner}buildTypes {{\n"
                f"{release_indent}release {{\n"
                f"{release_indent}    isMinifyEnabled = false\n"
                f"{release_indent}    isShrinkResources = false\n"
                f"{release_indent}}}\n{inner}}}\n"
            )
        else:
            new_block = (
                f"\n{inner}buildTypes {{\n"
                f"{release_indent}release {{\n"
                f"{release_indent}    minifyEnabled false\n"
                f"{release_indent}    shrinkResources false\n"
                f"{release_indent}}}\n{inner}}}\n"
            )
        gradle_text = gradle_text[: android[2]] + new_block + gradle_text[android[2] :]
        android = find_block(gradle_text, "android")
        build_types = find_block(gradle_text, "buildTypes", android[1], android[2])
        assert build_types is not None

    release = find_block(gradle_text, "release", build_types[1], build_types[2])
    if release is None:
        indent = build_types[0] + "    "
        inner = indent + "    "
        if is_kotlin:
            new_release = (
                f"\n{indent}release {{\n"
                f"{inner}isMinifyEnabled = false\n"
                f"{inner}isShrinkResources = false\n"
                f"{indent}}}\n"
            )
        else:
            new_release = (
                f"\n{indent}release {{\n"
                f"{inner}minifyEnabled false\n"
                f"{inner}shrinkResources false\n"
                f"{indent}}}\n"
            )
        gradle_text = gradle_text[: build_types[2]] + new_release + gradle_text[build_types[2] :]
        android = find_block(gradle_text, "android")
        build_types = find_block(gradle_text, "buildTypes", android[1], android[2])
        release = find_block(gradle_text, "release", build_types[1], build_types[2])
        assert release is not None

    body_start = release[1] + 1
    body_end = release[2]
    body = gradle_text[body_start:body_end]
    indent = release[0] + "    "
    options = (
        ("isMinifyEnabled", "isMinifyEnabled = false", r"(?m)^([ \t]*)isMinifyEnabled[ \t]*=[ \t]*(?:true|false)[ \t]*$"),
        ("isShrinkResources", "isShrinkResources = false", r"(?m)^([ \t]*)isShrinkResources[ \t]*=[ \t]*(?:true|false)[ \t]*$"),
    ) if is_kotlin else (
        ("minifyEnabled", "minifyEnabled false", r"(?m)^([ \t]*)minifyEnabled[ \t]+(?:true|false)[ \t]*$"),
        ("shrinkResources", "shrinkResources false", r"(?m)^([ \t]*)shrinkResources[ \t]+(?:true|false)[ \t]*$"),
    )
    for _, replacement, pattern in options:
        match = re.search(pattern, body)
        if match:
            body = re.sub(pattern, lambda m: m.group(1) + replacement, body, count=1)
        else:
            body = f"\n{indent}{replacement}" + body
    return gradle_text[:body_start] + body + gradle_text[body_end:]


def ensure_min_sdk(gradle_text: str, is_kotlin: bool) -> str:
    # Handle both current Kotlin DSL templates and older Groovy templates.
    pattern = re.compile(r"(?m)^([ \t]*)(minSdkVersion|minSdk)[ \t]*(?:=[ \t]*)?([^\n,]+)")
    match = pattern.search(gradle_text)
    if match:
        line_prefix = match.group(1)
        key = match.group(2)
        separator = " = " if is_kotlin else " "
        if key == "minSdkVersion" and not is_kotlin:
            replacement = f"{line_prefix}minSdkVersion 24"
        else:
            replacement = f"{line_prefix}minSdk{separator}24"
        return gradle_text[: match.start()] + replacement + gradle_text[match.end() :]

    default_config = find_block(gradle_text, "defaultConfig")
    if default_config is None:
        raise ValueError("Could not find defaultConfig { } to set Android minimum SDK")
    indent = default_config[0] + "    "
    line = f"\n{indent}{'minSdk = 24' if is_kotlin else 'minSdkVersion 24'}\n"
    return gradle_text[: default_config[2]] + line + gradle_text[default_config[2] :]


def patch_gradle_file(gradle_file: Path) -> None:
    is_kotlin = gradle_file.suffix == ".kts"
    content = gradle_file.read_text(encoding="utf-8")
    content = ensure_min_sdk(content, is_kotlin)
    content = ensure_release_options(content, is_kotlin)
    gradle_file.write_text(content.rstrip() + "\n", encoding="utf-8")


def configure_project(project: Path, repo_root: Path) -> None:
    project = project.resolve()
    android = project / "android"
    gradle_candidates = [android / "app" / "build.gradle.kts", android / "app" / "build.gradle"]
    gradle = next((p for p in gradle_candidates if p.is_file()), None)
    if gradle is None:
        raise FileNotFoundError(
            f"Android Gradle file not found under {android / 'app'}. "
            "Run flutter create --platforms=android . before this script."
        )

    manifest = android / "app" / "src" / "main" / "AndroidManifest.xml"
    if not manifest.is_file():
        raise FileNotFoundError(f"AndroidManifest.xml not found: {manifest}")
    manifest_text = manifest.read_text(encoding="utf-8")
    if "android.permission.CAMERA" not in manifest_text:
        manifest_text = re.sub(
            r"(<manifest\b[^>]*>)",
            r'\1\n    <uses-permission android:name="android.permission.CAMERA" />',
            manifest_text,
            count=1,
        )
    manifest_text, replacements = re.subn(
        r'android:label="[^"]*"', 'android:label="My Money"', manifest_text, count=1
    )
    if replacements == 0:
        raise ValueError("Could not set app label: android:label was not found in AndroidManifest.xml")
    manifest.write_text(manifest_text, encoding="utf-8")

    main_root = android / "app" / "src" / "main"
    kotlin_files = list(main_root.rglob("MainActivity.kt"))
    java_files = list(main_root.rglob("MainActivity.java"))
    if kotlin_files:
        activity = kotlin_files[0]
    else:
        for java_file in java_files:
            java_file.unlink()
        activity = main_root / "kotlin" / "id" / "mymoney" / "my_money" / "MainActivity.kt"
        activity.parent.mkdir(parents=True, exist_ok=True)
    activity.write_text(ACTIVITY_SOURCE, encoding="utf-8")

    patch_gradle_file(gradle)

    # Apply a branded launcher icon for both legacy launchers and Android 8+ adaptive icons.
    source_resources = repo_root / "android-assets" / "res"
    target_resources = android / "app" / "src" / "main" / "res"
    if not source_resources.is_dir():
        raise FileNotFoundError(f"Launcher icon resources are missing: {source_resources}")
    for source in source_resources.rglob("*"):
        if not source.is_file():
            continue
        rel = source.relative_to(source_resources)
        destination = target_resources / rel
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)

    print(f"Android project prepared: {project}")
    print(f"Gradle file configured: {gradle.name}")
    print("Minimum Android SDK: 24")
    print("Release R8 minification: disabled to avoid missing optional ML Kit classes")
    print("Camera permission and My Money launcher icon: configured")


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        print("Usage: python3 tool/prepare_android.py <flutter-project-directory>", file=sys.stderr)
        return 2
    project = Path(argv[1])
    try:
        configure_project(project, Path(__file__).resolve().parent.parent)
    except Exception as exc:  # keep CI log actionable
        print(f"ERROR preparing Android project: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
