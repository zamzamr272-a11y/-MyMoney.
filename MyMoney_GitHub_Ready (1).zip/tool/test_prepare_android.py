import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import prepare_android  # noqa: E402


KOTLIN_GRADLE = '''
plugins { id("com.android.application") }
android {
    namespace = "id.mymoney.my_money"
    defaultConfig {
        applicationId = "id.mymoney.my_money"
        minSdk = flutter.minSdkVersion
        targetSdk = flutter.targetSdkVersion
    }
    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
        }
    }
}
'''

GROOVY_GRADLE = '''
plugins { id 'com.android.application' }
android {
    namespace 'id.mymoney.my_money'
    defaultConfig {
        applicationId 'id.mymoney.my_money'
        minSdkVersion flutter.minSdkVersion
    }
    buildTypes {
        release {
            minifyEnabled true
            shrinkResources true
        }
    }
}
'''


class PrepareAndroidTests(unittest.TestCase):
    def test_kotlin_dsl_min_sdk_and_r8_settings(self):
        result = prepare_android.ensure_min_sdk(KOTLIN_GRADLE, is_kotlin=True)
        result = prepare_android.ensure_release_options(result, is_kotlin=True)
        self.assertIn('minSdk = 24', result)
        self.assertIn('isMinifyEnabled = false', result)
        self.assertIn('isShrinkResources = false', result)
        self.assertNotIn('isMinifyEnabled = true', result)
        self.assertNotIn('isShrinkResources = true', result)

    def test_groovy_dsl_min_sdk_and_r8_settings(self):
        result = prepare_android.ensure_min_sdk(GROOVY_GRADLE, is_kotlin=False)
        result = prepare_android.ensure_release_options(result, is_kotlin=False)
        self.assertIn('minSdkVersion 24', result)
        self.assertIn('minifyEnabled false', result)
        self.assertIn('shrinkResources false', result)
        self.assertNotIn('minifyEnabled true', result)
        self.assertNotIn('shrinkResources true', result)

    def test_kotlin_patch_is_idempotent(self):
        once = prepare_android.ensure_release_options(
            prepare_android.ensure_min_sdk(KOTLIN_GRADLE, is_kotlin=True), is_kotlin=True
        )
        twice = prepare_android.ensure_release_options(
            prepare_android.ensure_min_sdk(once, is_kotlin=True), is_kotlin=True
        )
        self.assertEqual(once, twice)
        self.assertEqual(twice.count('isMinifyEnabled = false'), 1)
        self.assertEqual(twice.count('isShrinkResources = false'), 1)

    def test_groovy_patch_is_idempotent(self):
        once = prepare_android.ensure_release_options(
            prepare_android.ensure_min_sdk(GROOVY_GRADLE, is_kotlin=False), is_kotlin=False
        )
        twice = prepare_android.ensure_release_options(
            prepare_android.ensure_min_sdk(once, is_kotlin=False), is_kotlin=False
        )
        self.assertEqual(once, twice)
        self.assertEqual(twice.count('minifyEnabled false'), 1)
        self.assertEqual(twice.count('shrinkResources false'), 1)

    def test_configure_project_integrates_manifest_activity_gradle_and_icons(self):
        with tempfile.TemporaryDirectory() as tmp:
            project = Path(tmp)
            android = project / "android"
            gradle = android / "app" / "build.gradle.kts"
            gradle.parent.mkdir(parents=True)
            gradle.write_text(KOTLIN_GRADLE, encoding="utf-8")
            manifest = android / "app" / "src" / "main" / "AndroidManifest.xml"
            manifest.parent.mkdir(parents=True)
            manifest.write_text(
                '<manifest xmlns:android="http://schemas.android.com/apk/res/android">\n'
                '  <application android:label="Runner" />\n</manifest>\n',
                encoding="utf-8",
            )
            java_activity = manifest.parent / "java" / "id" / "mymoney" / "my_money" / "MainActivity.java"
            java_activity.parent.mkdir(parents=True)
            java_activity.write_text("package id.mymoney.my_money; class MainActivity {}", encoding="utf-8")

            repository_root = Path(__file__).resolve().parent.parent
            prepare_android.configure_project(project, repository_root)

            patched_manifest = manifest.read_text(encoding="utf-8")
            self.assertIn('android.permission.CAMERA', patched_manifest)
            self.assertIn('android:label="My Money"', patched_manifest)
            self.assertFalse(java_activity.exists())
            kotlin_activity = manifest.parent / "kotlin" / "id" / "mymoney" / "my_money" / "MainActivity.kt"
            self.assertIn("FlutterFragmentActivity", kotlin_activity.read_text(encoding="utf-8"))
            self.assertIn("isMinifyEnabled = false", gradle.read_text(encoding="utf-8"))
            self.assertTrue((android / "app" / "src" / "main" / "res" / "mipmap-hdpi" / "ic_launcher.png").is_file())

    def test_adaptive_icon_xml_is_well_formed(self):
        import xml.etree.ElementTree as ET

        root = Path(__file__).resolve().parent.parent / 'android-assets' / 'res'
        for relative in [
            'mipmap-anydpi-v26/ic_launcher.xml',
            'mipmap-anydpi-v26/ic_launcher_round.xml',
            'drawable/ic_launcher_foreground.xml',
            'values/ic_launcher_background.xml',
        ]:
            with self.subTest(resource=relative):
                ET.parse(root / relative)


if __name__ == '__main__':
    unittest.main(verbosity=2)
